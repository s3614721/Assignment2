#! usr/bin/bash
echo
echo "Capslock"
echo
echo "What would you like to do with this led ?"
echo "1. on"
echo "2. off"
echo "3. associate with system event"
echo "4. associate with the performance of a process"
echo "5. stop association with a process’ performance "
echo "6. quit"
echo "Please enter choice from 1-6"
echo
read caps
COUNTER=0;
# while loop (not work)
while [ $COUNTER -eq 0 ] 
do
	COUNTER=$(( $COUNTER + 1 ))
	case $caps in			
		1) #turn led on
		     echo 1 | sudo tee /sys/class/leds/input*::capslock/brightness
				
				;;
		2) #turn led off
		    echo 0 | sudo tee /sys/class/leds/input*::capslock/brightness
				break
				;;
		3) #choose event for led 
		   cat /sys/class/leds/input2::capslock/trigger | xargs -n1
		   echo
		   echo "Please type the name of event correctly : "
		   echo
		   #The name of event need to be accurate
		   read event
		   #the event will be run with correct name
		   echo $event > /sys/class/leds/input2::capslock/trigger
				break
				;;
		4) 		
				break
				;;
				
		5) 
				break
				;;
		6) #exit 
			echo "See you again!"
				break
				;;
		*) echo "Choice is invalid"
			COUNTER=0 
				;;
	esac
done
