#! usr/bin/bash
echo
echo "Led 1"
echo
echo "What would you like to do with this led ?"
echo "1. on"
echo "2. off"
echo "3. associate with system event"
echo "4. associate with the performance of a process"
echo "5. stop association with a process’ performance "
echo "6. quit"
echo "Please enter choice from 1-6"
read led1
COUNTER=0;
while [ $COUNTER -eq 0 ]
do
	COUNTER=$(( $COUNTER + 1 ))
case $led1 in			
		1) echo 1 | sudo tee /sys/class/leds/led1/brightness
				;;
		2) echo 0 | sudo tee /sys/class/leds/led1/brightness
				;;
		3)cat /sys/class/leds/led1/trigger | xargs -n1
		   echo
		   echo "Please type the name of event correctly : "
		   echo
		   read event
		   echo $event > /sys/class/leds/led1/trigger
				break
				;;
		4)
				break
				;;
		5)
				break
				;;
		6)  #exit 
			echo "See you again!"
				break
				;;
		*) echo "Choice is invalid"
			COUNTER=0 
				;;
esac
done
