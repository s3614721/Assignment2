!/bin/bash

echo
echo "Welcome to Leds configuration"
echo "This configure is working in the input 2. Please plug your keyboard in input2"
echo " Please select an led to configure :  "
echo
ls -a /sys/class/leds | tail -7
echo "quit"
echo
echo "Warning : kana and compose are not available"
echo "Please type the exact name on the list to choose the leds (e.g : input2::capslock  ) : "
read option

case $option in
		#Enter Capslock Configure 
		#this choice connect to capslock.sh
		input*::capslock)   source capslock.sh
			;;
		#Enter Numlock Configure
		#this choice connect to numlock.sh
		input*::numlock)   source numlock.sh
			;;
		#Enter Scrolllock Configure
		#this choice connect to scrolllock.sh
		input*::scrolllock)  source scrolllock.sh
			;;
		#Enter led0 Configure
		#this choice connect to led0.sh
		led0) source led0.sh
			;;
		#Enter led1 Configure
		#this choice connect to led1.sh
		led1) source led1.sh
			;;
		#exit
		quit) echo "See you again!"
			break
			;;
		*) echo "Sorry, this led is not valid to configure"
esac





